"""Global thresholds and defaults for decision logic."""

RET_MIN = 0
RET_GOOD = 8
DD_WARN = 20
DD_MAX = 25
MIN_TRADES = 12
TPW_TARGET = 2
TPW_TOL = 1
